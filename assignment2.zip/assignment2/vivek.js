console.log('namaste dunia');
let a=  'vivu';v  
console. log(a)

const num=10;
  num= 10;
